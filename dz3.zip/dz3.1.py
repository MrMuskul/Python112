a = input("1-й символ: ")
b = input("2-й символ: ")
c = int(input("Кол-во столбцов: "))

for i in range(1, c):
    print((a+b)*c)